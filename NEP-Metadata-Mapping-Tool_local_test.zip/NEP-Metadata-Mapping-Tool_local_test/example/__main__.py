import NEPMetadataMapping

NEPMetadataMapping.DicomMapping(map='./map.json',
                                metadata="PATH/dicomFiles.zip",
                                mappedMetadata="mappedMetadata.json")
