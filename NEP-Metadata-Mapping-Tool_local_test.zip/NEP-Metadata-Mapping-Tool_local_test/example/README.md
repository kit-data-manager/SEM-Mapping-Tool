# Example
In order to run the provided example, the user has to install the Python module and add it to the virtual environment the supported Python version (3 up to 3.8) is running.

The easiest way to execute the components of the module is by calling the DicomMapping class, which maps the metadata for any dicom study and a schema. The user then only has to provide the attribute associations from the dicom standard to the schema.
